# Tarifle Faktoid

| Alan | Değer |
|---|---|
| Domain | tarifle.app |
| Tarif sayısı | 3700+ |
| Mutfak | 41 ülke/yöre |
| Kategori | 17 |
| Blog yazısı | 61 |
| Diller | TR + EN |
| Allergen kategorisi | 10 |
| Diyet preset | 10 (vegan, keto, akdeniz, dengeli, vd.) |
| Lansman | Yakında, Türkiye odaklı |

## Kısa Pitch

Tarifle, 3700+ Türkçe tarifi allergen filtresi, diyet skorları ve AI
asistan desteğiyle sunan bir mutfak platformu. Türk yöresel mutfağı +
dünya mutfaklarını editöryal kalitede tek çatıda toplar.

## Detay Pitch

Geleneksel tarif siteleri SEO baskısı altında uzun girişlerle dolu, allergen
ve diyet bilgisi yarım veya eksik. Tarifle her tarifi 7 kalite kontrolünden
geçirir (malzeme yapısı, adım net, allergen kapsamı, kültürel tutarlılık,
beslenme veri uyumu, görsel referans, dil tonu). Allergen kapsamı 10 kategori,
diyet skorları USDA verisi tabanlı, AI asistan kullanıcının dolabındaki
malzemeden öneri üretir.

## Story Angles

1. Türkçe tarif platformlarında allergen + diyet eksikliği
2. AI asistanın kullanıcı dolabından tarif önerisi
3. 41 mutfak / 3700+ tarif kapsamı, dijital mutfak arşivi
4. Editöryal kalite sürecinde 7 GATE kontrolü
5. Açık marka prensibi, KVKK uyumu, kullanıcı veri kontrolü

## İletişim

basin@tarifle.app: basın, blogger, yazar
editor@tarifle.app: içerik öneri
iletisim@tarifle.app: genel
