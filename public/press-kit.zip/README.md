# Tarifle Basın Kiti

Tarifle (tarifle.app), Türkçe odaklı tarif platformu. Bu paket marka
asset'leri ve faktoid bilgisi içerir. Yazılı izin gerekmez, ticari kullanımda
da serbestsin, sadece logoyu deforme etme + Tarifle adını yanlış yazma.

## Logo Dosyaları

| Dosya | Kullanım |
|---|---|
| primary.svg / .png | Renkli ana logo, beyaz veya açık arka planda |
| wordmark.svg / .png | Yatay sözcük markı, footer/banner için |
| icon.svg / .png | Yalnız simge, dar alan ve sosyal medya |
| mono-dark.svg / .png | Tek renk koyu, açık arka plan üzerine |
| mono-light.svg / .png | Tek renk açık, koyu arka plan üzerine |
| favicon.ico, favicon-16/32.png | Tarayıcı ikonları |
| apple-touch-icon.png | iOS home screen |
| og-image.png | Sosyal paylaşım önizleme (1200x630) |

## Renk Paleti

| Token | Hex | Kullanım |
|---|---|---|
| Brand primary | #a03b0f | Ana vurgu, link, CTA buton |
| Text | #1a1a1a | Gövde metin |
| Background | #f8f6f2 | Genel arka plan |
| Card | #ffffff | Kart yüzeyi |
| Border | #ddd8cf | Kart kenarı, ayırıcı |

## Tipografi

- Heading: serif font (sistem fallback ile)
- Body: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto

## Kullanım Kuralları

- Logoyu deforme etme (gerdirme, çevirme, renk değiştirme yok)
- Marka adını her zaman "Tarifle" olarak yaz, küçük harfle "tarifle" sadece
  URL/handle bağlamında ([tarifle.app](https://tarifle.app), @tarifle vs.)
- Logo etrafında en az logo yüksekliği kadar boşluk bırak
- "Tarif" + "le" ayrılarak yazılmaz, tek kelime

## Yasaklar

- Logo üzerine yazı veya grafik bindirme
- Marka renginin dışında renk varyasyonu (mono varyantlar dışında)
- Yanıltıcı bağlam (Tarifle olarak konuşma, sponsorluk imajı yaratma)

## İletişim

Basın, blogger, yazar talepleri: basin@tarifle.app
Editöryal öneri ve içerik feedback: editor@tarifle.app
